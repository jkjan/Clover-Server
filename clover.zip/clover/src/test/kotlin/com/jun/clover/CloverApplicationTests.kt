package com.jun.clover

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CloverApplicationTests {

	@Test
	fun contextLoads() {
	}

}
